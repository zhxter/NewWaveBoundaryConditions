/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright held by original author
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

\*---------------------------------------------------------------------------*/

#include "newWaveSecondorder.H"
#include "addToRunTimeSelectionTable.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{
namespace waveTheories
{

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

defineTypeNameAndDebug(newWaveSecondorder, 0);
addToRunTimeSelectionTable(waveTheory, newWaveSecondorder, dictionary);

// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

newWaveSecondorder::newWaveSecondorder
(
    const word& subDictName,
    const fvMesh& mesh_
)
:
    waveTheory(subDictName, mesh_),//,
    //H_(readScalar(coeffDict_.lookup("height"))),
    //Add the other variables
    //Tsoft_(coeffDict_.lookupOrDefault<scalar>("Tsoft",period_))
    N_(readScalar(coeffDict_.lookup("N"))),                               //This the method of reading scalar data from dictionary or subdictionary. For reading vector, just delete 'readScalar'
    h_(readScalar(coeffDict_.lookup("depth"))),  
    amp_("amplitude", coeffDict_, N_),                   
    omega_("frequency", coeffDict_, N_),                                  // This is the method of reading a data list from a dictionary or subdictionary
    phi_("phaselag", coeffDict_, N_),
    k_("waveNumber", coeffDict_, N_),
    K_(N_), 
    compDir_(N_),  // because compDir_ is a field, so if just one value is given in the bracket, it represents the number of elements in this field. the second value in the bracket is the initial value
    period_(N_, 0),  // Period_ has N_ compoents and the initial value of each component is 0
    velAmp_(N_, 0), 

    Tsoft_( readScalar(coeffDict_.lookup("Tsoft")))   
{
    omega_ *= (2.0*PI_);

    // Compute the length of k_
    K_ = Foam::mag(k_);

    compDir_ = k_ / K_;

    // Compute the period
    forAll (period_, index)
    {
        period_[index] = 2.0*PI_/omega_[index];
    }

    // Compute the velocity amplitude, just part of the amplitude of the velocity
    forAll (velAmp_, index)
    {
        velAmp_[index] = PI_*2.0*amp_[index]/period_[index]
            /Foam::sinh(K_[index]*h_);
    }

    checkWaveDirection(k_);
}


void newWaveSecondorder::printCoeffs()
{
    Info << "Loading wave theory: " << typeName << endl;
}

// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //


scalar newWaveSecondorder::factor(const scalar& time) const
{
    scalar factor(1.0);
    if (Tsoft_ > 0.0)
    {
        factor = Foam::sin(2*PI_/(4.0*Tsoft_)*Foam::min(Tsoft_, time));
    }

    return factor;
}

scalar newWaveSecondorder::eta
(
    const point& x,
    const scalar& time
) const
{
    scalar eta = 0.0;

    // Cacluate the first order term
    
    forAll (amp_, index)                       
    {
        scalar arg = omega_[index]*time - (k_[index] & x) + phi_[index];
        eta += amp_[index]*Foam::cos(arg);
    }

//calculate the second order sum frequency term, refer to Westphalen et al. (2012) Focused waves  and wave structure interaction in a numerical wave tank
// or refer to Dalzell (1999) A note on finite depth second order wave wave interactions

    for (int i=0; i<N_-1; i++)                      
    {
        scalar argi = omega_[i]*time - (k_[i] & x) + phi_[i];
        scalar cosineki=k_[i][0]/K_[i];           //calculate the cosine of the angle of wave number vecotor with x axis for ith wave component
        scalar sineki=k_[i][1]/K_[i];             //calculate the sine of the angle of wave number vector with x axis for ith wave component
        for (int j=i+1; j<N_; j++)
        { 
             scalar argj = omega_[j]*time - (k_[j] & x) + phi_[j];
             scalar cosinekj=k_[j][0]/K_[j];      //calculate the the cosine of the angle of wave number vecotor with x axis for jth wave component
             scalar sinekj=k_[j][1]/K_[j];        //calculate the sine of the angle of wave number vecotor with x axis for jth wave component
             scalar cosinekiminuskj=cosineki*cosinekj+sineki*sinekj;  
             scalar Dijplus=Foam::pow(omega_[i]+omega_[j],2) - Foam::mag(g_)*Foam::mag(k_[i]+k_[j])*Foam::tanh(Foam::mag((k_[i]+k_[j])*h_));
             scalar Bijplus=(Foam::pow(omega_[i],2) + Foam::pow(omega_[j],2))/2/Foam::mag(g_) - omega_[i]*omega_[j]/2/Foam::mag(g_) * ( 1 - cosinekiminuskj/Foam::tanh(K_[i]*h_)/Foam::tanh(K_[j]*h_) )
                      *(Foam::pow(omega_[i]+omega_[j],2)+Foam::mag(g_)*Foam::mag(k_[i]+k_[j])*Foam::tanh(Foam::mag(k_[i]+k_[j])*h_))/Dijplus
                      + (omega_[i]+omega_[j])/2/Foam::mag(g_)/Dijplus*(Foam::pow(omega_[i],3)/Foam::pow(Foam::sinh(K_[i]*h_),2) + Foam::pow(omega_[j],3)/Foam::pow(Foam::sinh(K_[j]*h_),2));
             eta += amp_[i]*amp_[j]*Bijplus*Foam::cos(argi+argj);
        }
     }

// Calculate the second order difference frequency term

    for (int i=0; i<N_-1; i++)                      
    {
        scalar argi = omega_[i]*time - (k_[i] & x) + phi_[i];
        scalar cosineki=k_[i][0]/K_[i];           //calculate the cosine of the angle of wave number vecotor with x axis for ith wave component
        scalar sineki=k_[i][1]/K_[i];             //calculate the sine of the angle of wave number vector with x axis for ith wave component
        for (int j=i+1; j<N_; j++)
        { 
             scalar argj = omega_[j]*time - (k_[j] & x) + phi_[j];
             scalar cosinekj=k_[j][0]/K_[j];      //calculate the the cosine of the angle of wave number vecotor with x axis for jth wave component
             scalar sinekj=k_[j][1]/K_[j];        //calculate the sine of the angle of wave number vecotor with x axis for jth wave component
             scalar cosinekiminuskj=cosineki*cosinekj+sineki*sinekj;  
             scalar Dijminus=Foam::pow(omega_[i]-omega_[j],2) - Foam::mag(g_)* Foam::mag(k_[i]-k_[j])*Foam::tanh(Foam::mag((k_[i]-k_[j])*h_));
             scalar Bijminus=(Foam::pow(omega_[i],2) + Foam::pow(omega_[j],2))/2/Foam::mag(g_) + omega_[i]*omega_[j]/2/Foam::mag(g_) * ( 1 + cosinekiminuskj/Foam::tanh(K_[i]*h_)/Foam::tanh(K_[j]*h_) )
                      *(Foam::pow(omega_[i]-omega_[j],2)+Foam::mag(g_)*Foam::mag(k_[i]-k_[j])*Foam::tanh(Foam::mag(k_[i]-k_[j])*h_))/Dijminus
                      + (omega_[i]-omega_[j])/2/Foam::mag(g_)/Dijminus*(Foam::pow(omega_[i],3)/Foam::pow(Foam::sinh(K_[i]*h_),2) - Foam::pow(omega_[j],3)/Foam::pow(Foam::sinh(K_[j]*h_),2));
             eta += amp_[i]*amp_[j]*Bijminus*Foam::cos(argi-argj);
        }
     }

//  Calculate the second order twice frequency term

    forAll (amp_, index)                       
    {
        scalar arg = omega_[index]*time - (k_[index] & x) + phi_[index];
        eta += Foam::pow(amp_[index],2)*K_[index]/4/Foam::tanh(K_[index]*h_)*(2+3/Foam::pow(Foam::sinh(K_[index]*h_),2))*Foam::cos(2*arg);
    }

//  Calculate the second order deviation term ( deviated from mean still water surface)

    forAll (amp_, index)                       
    {
        eta -= Foam::pow(amp_[index],2)*K_[index]/2/Foam::sinh(2*K_[index]*h_);
    }

    eta *= factor(time);
    eta += seaLevel_;

    return eta;
}

scalar newWaveSecondorder::ddxPd
(
    const point& x,
    const scalar& time,
    const vector& unitVector
) const
{

    scalar ddxPd(0);
    // Most theories return 0, as the issue with oblique waves has not
    // yet been derived.

    return ddxPd;
}

vector newWaveSecondorder::U
(
    const point& x,
    const scalar& time
) const
{

    // This gives the z-coordinate relative to seaLevel
    scalar Z(returnZ(x));

    vector U(vector::zero);

    
    // Calculate the first order (linear) velocity term
    forAll (amp_, index)
    {
        scalar arg0 = omega_[index]*time - (k_[index] & x) + phi_[index];
        scalar arg1 = K_[index]*(Z + h_);

        scalar Uhorz = velAmp_[index]*Foam::cosh(arg1)*Foam::cos(arg0);
        scalar Uvert = - velAmp_[index]*Foam::sinh(arg1)*Foam::sin(arg0);

        // Note "-" because of "g" working in the opposite direction
        U += Uhorz*compDir_[index] - Uvert*direction_;
    }

    // Calculate the second order sum frequency term

    for (int i=0; i<N_-1; i++)                      
    {
        scalar argi = omega_[i]*time - (k_[i] & x) + phi_[i];
        scalar cosineki=k_[i][0]/K_[i];           //calculate the cosine of the angle of wave number vecotor with x axis for ith wave component
        scalar sineki=k_[i][1]/K_[i];             //calculate the sine of the angle of wave number vector with x axis for ith wave component
        for (int j=i+1; j<N_; j++)
        {
             scalar argj =  omega_[j]*time - (k_[j] & x) + phi_[j];  
             scalar cosinekj=k_[j][0]/K_[j];      //calculate the the cosine of the angle of wave number vecotor with x axis for jth wave component
             scalar sinekj=k_[j][1]/K_[j];        //calculate the sine of the angle of wave number vecotor with x axis for jth wave component
             scalar cosinekiminuskj=cosineki*cosinekj+sineki*sinekj;    
             scalar Dijplus=Foam::pow(omega_[i]+omega_[j],2) - Foam::mag(g_)* Foam::mag(k_[i]+k_[j])*Foam::tanh(Foam::mag((k_[i]+k_[j])*h_));
             scalar Aijplus=- omega_[i]*omega_[j]*(omega_[i]+omega_[j])/Dijplus * (1 - cosinekiminuskj/Foam::tanh(K_[i]*h_)/Foam::tanh(K_[j]*h_))
                     + 1/2/Dijplus*(Foam::pow(omega_[i],3)/Foam::pow(Foam::sinh(K_[i]*h_),2) + Foam::pow(omega_[j],3)/Foam::pow(Foam::sinh(K_[j]*h_),2));
             
             scalar Uhorz = amp_[i]*amp_[j]*Foam::mag(k_[i]+k_[j])*Aijplus*Foam::cosh(Foam::mag(k_[i]+k_[j])*(Z+h_))/cosh(Foam::mag(k_[i]+k_[j])*h_)*Foam::cos(argi+argj);
             scalar Uvert = - amp_[i]*amp_[j]*Foam::mag(k_[i]+k_[j])*Aijplus*Foam::sinh(Foam::mag(k_[i]+k_[j])*(Z+h_))/cosh(Foam::mag(k_[i]+k_[j])*h_)*Foam::sin(argi+argj);
             vector compDirsumfreq=(k_[i]+k_[j])/Foam::mag(k_[i]+k_[j]);
             U += Uhorz*compDirsumfreq - Uvert*direction_;
         }
    }

    // Calculate the second order difference frequency term
    
    for (int i=0; i<N_-1; i++)                      
    {
        scalar argi = omega_[i]*time - (k_[i] & x) + phi_[i];
        scalar cosineki=k_[i][0]/K_[i];           //calculate the cosine of the angle of wave number vecotor with x axis for ith wave component
        scalar sineki=k_[i][1]/K_[i];             //calculate the sine of the angle of wave number vector with x axis for ith wave component
        for (int j=i+1; j<N_; j++)
        {
             scalar argj =  omega_[j]*time - (k_[j] & x) + phi_[j]; 
             scalar cosinekj=k_[j][0]/K_[j];      //calculate the the cosine of the angle of wave number vecotor with x axis for jth wave component
             scalar sinekj=k_[j][1]/K_[j];        //calculate the sine of the angle of wave number vecotor with x axis for jth wave component
             scalar cosinekiminuskj=cosineki*cosinekj+sineki*sinekj;       
             scalar Dijminus=Foam::pow(omega_[i]-omega_[j],2) - Foam::mag(g_)* Foam::mag(k_[i]-k_[j])*Foam::tanh(Foam::mag((k_[i]-k_[j])*h_));
             scalar Aijminus= omega_[i]*omega_[j]*(omega_[i]-omega_[j])/Dijminus * (1 + cosinekiminuskj/Foam::tanh(K_[i]*h_)/Foam::tanh(K_[j]*h_))
                     + 1/2/Dijminus*(Foam::pow(omega_[i],3)/Foam::pow(Foam::sinh(K_[i]*h_),2) - Foam::pow(omega_[j],3)/Foam::pow(Foam::sinh(K_[j]*h_),2));
             
             scalar Uhorz = amp_[i]*amp_[j]*Foam::mag(k_[i]-k_[j])*Aijminus*Foam::cosh(Foam::mag(k_[i]-k_[j])*(Z+h_))/cosh(Foam::mag(k_[i]-k_[j])*h_)*Foam::cos(argi-argj);
             scalar Uvert = - amp_[i]*amp_[j]*Foam::mag(k_[i]-k_[j])*Aijminus*Foam::sinh(Foam::mag(k_[i]-k_[j])*(Z+h_))/cosh(Foam::mag(k_[i]-k_[j])*h_)*Foam::sin(argi-argj);
             vector compDirdifffreq=(k_[i]-k_[j])/Foam::mag(k_[i]-k_[j]);
             U += Uhorz*compDirdifffreq - Uvert*direction_;
         }
    }    

    // Calculate the second order twice frequency term

    forAll (amp_, index)
    {
        scalar arg0 = omega_[index]*time - (k_[index] & x) + phi_[index];
        
        scalar Uhorz = Foam::pow(amp_[index],2)*omega_[index]*K_[index]*3/4*Foam::cosh(2*K_[index]*(Z+h_))/Foam::pow(Foam::sinh(K_[index]*h_),4)*Foam::cos(2*arg0);
        scalar Uvert = - Foam::pow(amp_[index],2)*omega_[index]*K_[index]*3/4*Foam::sinh(2*K_[index]*(Z+h_))/Foam::pow(Foam::sinh(K_[index]*h_),4)*Foam::sin(2*arg0);
        vector compDirtwicefreq=(2*k_[index])/Foam::mag(2*k_[index]);
        // Note "-" because of "g" working in the opposite direction
        U += Uhorz*compDirtwicefreq - Uvert*direction_;
    }


    U *= factor(time);

    return U;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace waveTheories
} // End namespace Foam

// ************************************************************************* //
